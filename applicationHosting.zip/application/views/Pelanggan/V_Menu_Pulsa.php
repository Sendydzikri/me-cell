<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
	<title>Menu Utama</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/Bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">

    <style>
        table{
            margin-left: 120px;
        }
        .no_hp{
            margin-left: 1110px;
        }
        .kontak {
  background-color: #2e2e2e;
  margin-top: 150px;
}

    </style>
</head>
<body>
    
      <!-- <div id="sideNavigation" class="sidenav">
        
    
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <a href="#"><img src="image/home.png" width="30" height="30">Utama</a>
          <hr class="my-1" color="#fff">
          <a href="#"> <img src="image/categories.png" width="30" height="30">Kategori</a>
          <hr class="my-1" color="#fff">
          <a href="#"><img src="image/cards.png" width="30" height="30">Kartu Perdana</a>
          <a href="#"><img src="image/kuota (1).png" width="30" height="30">Kartu Kuota</a>
          <a href="aksesoris.html"><img src="image/aksesoris.png" width="30" height="30">Aksesoris</a>
          <a href="#"><img src="image/pulsa.png" width="30" height="30">Pulsa</a><p><p><p><br><br><br>

          <br><br><br><br><a href="#"><a href="#"><img src="image/logout.png" width="30" height="30">Keluar</a>

          
        </div>
        
            <nav class="topnav">
        
          <a href="#" onclick="openNav()">         
            <svg width="30" height="30" id="icoOpen">
                <path d="M0,5 30,5" stroke="#000" stroke-width="5"/>
                <path d="M0,14 30,14" stroke="#000" stroke-width="5"/>
                <path d="M0,23 30,23" stroke="#000" stroke-width="5"/>
            </svg>
            
          </a>
         </nav>  
        <nav class="navbar navbar-light bg-light justify-content-between">
          <a class="navbar-brand"></a>
          <div class="button-add">
            <a href="keranjang.html">
          <button type="button" class="btn btn-outline-light"><image src="image\add.png" width=30 height=30></image></button>
        </a>
          <button type="button" class="btn btn-outline-light"><image src="image\chat.png" width=30 height=30></image></button>
      </div>
        
          <form class="form-inline">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-0 my-sm-0" type="submit">Search</button>
          </form>
      </div>
        </nav>
      
      <br> -->


</div>
     <br>
     <br>
      <table>
        <tr>
            <td>
              <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method = "POST" >
               <div class="card" style="width: 18rem;">
                   <div class="card-body">
                     <h5 class="card-title">Pulsa 5.000</h5>
                     <h6 class="card-subtitle mb-2 text-muted">Harga Rp7.000</h6>
                     <input type = "text" name ="noHp" placeholder = "Masukkan No HP">
                     <input type = "text" name = "harga" value="7000" hidden> 
                     <input type = "text" name = "saldo" value="5000" hidden> 
                     <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                   </div>
                 </div>
              </form>
            </td>
            
            <td>
              <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method = "POST">
               <div class="card" style="width: 18rem;">
                   <div class="card-body">
                     <h5 class="card-title">Pulsa 10.000</h5>
                     <h6 class="card-subtitle mb-2 text-muted">Harga Rp12.000</h6>
                     <input type = "text" name ="noHp" placeholder = "Masukkan No HP">
                     <input type = "text" name = "harga" value="12000" hidden> 
                     <input type = "text" name = "saldo" value="10000" hidden> 
                      <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                   </div>
                 </div>
                </form>
            </td>
            <td>
                <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method = "POST">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                      <h5 class="card-title">Pulsa 25.000</h5>
                      <h6 class="card-subtitle mb-2 text-muted">Harga Rp27.000</h6>
                      <input type = "text" name ="noHp" placeholde = "Masukkan No HP">
                      <input type = "text" name = "harga" value="27000" hidden> 
                      <input type = "text" name = "saldo" value="25000" hidden> 
                      <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                    </div>
                  </div>
                </form>
             </td>
        </tr>

        <tr>
            <td>
              <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method = "POST">
               <div class="card" style="width: 18rem;">
                   <div class="card-body">
                     <h5 class="card-title">Pulsa 50.000</h5>
                     <h6 class="card-subtitle mb-2 text-muted">Harga Rp52.000</h6>
                     <input type = "text" name ="noHp" placeholde = "Masukkan No HP">
                     <input type = "text" name = "harga" value="52000" hidden> 
                     <input type = "text" name = "saldo" value="50000" hidden> 
                     <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                   </div>
                 </div>
                </form>
            </td>
   <br>
            <td>
                <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method = "POST">
               <div class="card" style="width: 18rem;">
                   <div class="card-body">
                     <h5 class="card-title">Pulsa 100.000</h5>
                     <h6 class="card-subtitle mb-2 text-muted">Harga Rp102.000</h6>
                     <input type = "text" name ="noHp" placeholder = "Masukkan No HP">
                     <input type = "text" name = "harga" value="102000" hidden> 
                     <input type = "text" name = "saldo" value="100000" hidden> 
                     <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                   </div>
                 </div>
                </form>
            </td>
            <td>
                <form action = "<?php echo base_url('index.php/C_Pelanggan/transPulsa') ?>" method ="POST">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                      <h5 class="card-title">Pulsa 200.000</h5>
                      <h6 class="card-subtitle mb-2 text-muted">Harga Rp202.000</h6>
                      <input type = "text" name ="noHp" placeholder = "Masukan No HP">
                      <input type = "text" name = "harga" value="200000" hidden> 
                     <input type = "text" name = "saldo" value="2020000" hidden> 
                      <button class="btn btn-outline-success my-0 my-sm-0" type="submit" class="card-link">BELI</a>
                    </div>
                  </div>
                </form>
             </td>
        </tr>
    </table>
    <br> <br>

     
      <!-- KONTAK --> 
      <div class="kontak"
      <hr class="my-1">
<section id="contact" class="dark-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="section-title">
                    <h2>Alamat :</h2>
                    <p>Jl Jendral Audirman Basis kel Baros kec.Cimahi Tengah <br>Kota Cimahi</p>
  
</div>


             
      
      
      <script>
        function openNav() {
            document.getElementById("sideNavigation").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }
         
        function closeNav() {
            document.getElementById("sideNavigation").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
        </script>

        

</body>
</html>