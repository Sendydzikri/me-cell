<html>

	<head>
		<title> Contoh Register </title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/contoh.css'); ?>">
	</head>
	<body>
		<h1> Iwang tampan </h1>