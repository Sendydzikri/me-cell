<!--Judul Halaman-->
<center>
    <h1 class="display-6">HALAMAN UTAMA KASIR</h1>
</center>



<!--Konten-->
<div class="container d-flex justify-content-center mt-4">
    <a href="<?php echo base_url('index.php/C_Kasir/tampilKartuKuota') ?>" class="btn btn-dark btn-lg gk margin">Kartu
        Kuota
        <img src="<?php echo base_url('assets/image/kuota (1).png'); ?>" class="gk" width="30" height="30"></a>
    <a href="<?php echo base_url('index.php/C_Kasir/tampilPerdana') ?>" class="btn btn-dark btn-lg gk margin">Kartu
        Perdana
        <img src="<?php echo base_url('assets/image/perdana.png'); ?>" class="gk" width="30" height="30"></a>
    <a href="<?php echo base_url('index.php/C_Kasir/tampilAksesoris') ?>"
        class="btn btn-dark btn-lg gk margin">Aksesoris
        <img src="<?php echo base_url('assets/image/aksesoris.png'); ?>" class="gk" width="30" height="30"></a>
</div>