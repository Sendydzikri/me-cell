
     

       <!--Konten-->
    
        <br><br><br>

        
<div class="row justify-content-center align-items-center" style="margin-bottom:200px;">
            
                        <!-- Earnings (Monthly) Card Example -->
                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 ol-md-4 mb-4">
                             <a href="<?= base_url('C_Admin/tampilKelolaKasir');?>">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Kelola Data Kasir</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300">
                                               <img src="<?php echo base_url('assets/image/kasir.png'); ?>" width="60" height="60">
                                            </i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-5 mb-4">
                            <a href="<?= base_url('C_Barang');?>">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Kelola Barang</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-comments fa-2x text-gray-300">
                                               <img src="<?php echo base_url('assets/image/barang.png'); ?>" width="60" height="60">
                                            </i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>

                </div>
</div>
