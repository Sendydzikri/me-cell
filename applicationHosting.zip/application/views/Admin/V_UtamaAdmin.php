   <!--Judul Halaman-->
   <center>
       <h1 class="display-6">HALAMAN UTAMA ADMIN</h1>
   </center>



   <!--Konten-->
   <div class="container d-flex justify-content-center mt-4">
       <center>
           <img src="<?php echo base_url('assets/image/logo.png'); ?>" class="img-fluid" width="1000">
       </center>
   </div>