  <!-- KONTAK -->
  <br><br><br>
  <div class="kontak">
      <hr class="my-1">
      <section id="contact" class="dark-bg">
          <div class="container">
              <div class="row">
                  <div class="col-lg-12 text-center">
                      <div class="section-title">
                          <h2>Alamat :</h2>
                          <p>Jl Jendral Sudirman Basis kel Baros kec.Cimahi Tengah <br>Kota Cimahi</p>

                      </div>
                    </div>
                  </div>
                </div>
               </section>
               </div>
                

                      <script>
                      function openNav() {
                          document.getElementById("sideNavigation").style.width = "250px";
                          document.getElementById("main").style.marginLeft = "250px";
                      }

                      function closeNav() {
                          document.getElementById("sideNavigation").style.width = "0";
                          document.getElementById("main").style.marginLeft = "0";
                      }
                      </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="<?= base_url('assets/js/datatables-simple-demo.js'); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
   
        
        <script type="text/javascript" src="<?php echo base_url('assets/js/sidenav.js'); ?>"></script>></script>

       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script  src="<?= base_url ();?>assets/js/sweetalert2.all.min.js"></script> 


        <script type="text/javascript" src="<?php echo base_url('assets/js/keranjang.js'); ?>"></script></script>
    </body>

</html>