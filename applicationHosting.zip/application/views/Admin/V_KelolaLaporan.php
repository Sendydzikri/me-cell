<div class="container text-center" style="margin-bottom: 120px; margin-top:200px;"> 

        <a href="<?= base_url('C_Admin/laporanBarang/'); ?>" class="btn btn-success btn-lg">Laporan Barang</a>

        <a href="<?= base_url('C_Admin/laporanUser/'); ?>" class="btn btn-success btn-lg">Laporan User</a>

        <a href="<?= base_url('C_Admin/laporanKuota/'); ?>" class="btn btn-success btn-lg">Laporan Kuota</a>

        <a href="<?= base_url('C_Admin/laporanPulsa/'); ?>" class="btn btn-success btn-lg">Laporan Pulsa</a>

</div>